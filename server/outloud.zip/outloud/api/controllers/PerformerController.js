/**
 * PerformerController
 *
 * @description :: Server-side logic for managing performers
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

